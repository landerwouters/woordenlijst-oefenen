const wordForm = document.getElementById('wordForm');
const wordInput = document.getElementById('wordInput');
const wordPractice = document.getElementById('wordPractice');
const wordDisplay = document.getElementById('wordDisplay');
const answerInput = document.getElementById('answerInput');
const checkAnswer = document.getElementById('checkAnswer');
const feedback = document.getElementById('feedback');
const nextWord = document.getElementById('nextWord');

let words = [];
let currentWordIndex = 0;

// Woordenlijst opslaan
wordForm.addEventListener('submit', function(event) {
    event.preventDefault();
    const wordText = wordInput.value.trim();
    if (wordText) {
        words = wordText.split(',').map(word => word.trim());
        currentWordIndex = 0;
        startPractice();
    }
});

// Woorden oefenen
function startPractice() {
    wordPractice.style.display = 'block';
    displayWord();
}

// Toon het huidige woord
function displayWord() {
    if (currentWordIndex < words.length) {
        wordDisplay.textContent = `Woord: ${words[currentWordIndex]}`;
        feedback.textContent = '';
        answerInput.value = '';
    } else {
        wordDisplay.textContent = 'Je hebt alle woorden geoefend!';
        feedback.textContent = '';
        answerInput.style.display = 'none';
        checkAnswer.style.display = 'none';
        nextWord.style.display = 'none';
    }
}

// Antwoord controleren
checkAnswer.addEventListener('click', function() {
    const userAnswer = answerInput.value.trim();
    const correctAnswer = words[currentWordIndex];
    if (userAnswer.toLowerCase() === correctAnswer.toLowerCase()) {
        feedback.textContent = 'Correct!';
    } else {
        feedback.textContent = `Fout, het juiste woord is: ${correctAnswer}`;
    }
});

// Naar het volgende woord
nextWord.addEventListener('click', function() {
    currentWordIndex++;
    displayWord();
});
